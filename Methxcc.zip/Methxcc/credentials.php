<?php
define('USERNAME', 'methxcc');
define('PASSWORD', 'methxcc');
?>
						